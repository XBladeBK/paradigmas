from persona import persona

class Empleado (persona):
	#A IMPLEMENTAR

	def __init__(self):
		fecha_ing=fecha_ing

