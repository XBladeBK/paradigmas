from lugar import Lugar
from cliente import Cliente
#TODO
class Lavadero(Lugar):
	#A IMPLEMENTAR
	def __init__(lugar):
		pass			
