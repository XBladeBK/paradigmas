from estacionamiento import Estacionamiento
from cliente import Cliente
from ticket import Ticket
from model import Model
from automovil import Automovil
from controller import Controller
if __name__ =='__main__':
	c = Controller()
	
	
	
	
	

