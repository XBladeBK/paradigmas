from persistent import Persistent


class Automovil (Persistent):
	
	
	def __init__(self):	
		self.chapa=None
		self.color=None
		self.anio=None
		self.modelo=None
		self.marca=None

	
	
		
